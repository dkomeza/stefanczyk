import hashlib

passwd = 'Qwerty123!'.encode()
print(hashlib.sha256(passwd).hexdigest())
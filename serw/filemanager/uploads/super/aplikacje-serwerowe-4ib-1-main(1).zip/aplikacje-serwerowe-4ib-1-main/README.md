# Grades in Python
## Table of contents
* [General info](#general-info)
* [Technologies](#technologies)
## General info
Aplikacja webowa z materiałami do przedmiotu Aplikacje serwerowe dla klasy 4.

## Technologies
- Python 3.10
- Flask 2.2.2
- Flask-BS4 5.2.2.0
- Flask-Moment 1.0.5
- HTML 5.0
- CSS 3.0
- JavaScript

### License Server - JetBrains
    http://10.0.0.36:8080

### Python modules
    File/Settings/Project name/Python interpreter

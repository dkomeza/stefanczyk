from flask import Flask, render_template, request, session, redirect, url_for, flash
from flask_bs4 import Bootstrap
from flask_moment import Moment
from datetime import datetime
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, IntegerField
from wtforms.validators import DataRequired
from math import sqrt

app = Flask(__name__)
bootstrap = Bootstrap(app)
moment = Moment(app)
app.config['SECRET_KEY'] = 'ghj5678(*^678&*(hjk&*JKL'

class NameForm(FlaskForm):
    userName = StringField('Podaj swoje imię: ', validators=[DataRequired()])
    submit = SubmitField('Wyślij')

class FunctionForm(FlaskForm):
    a = IntegerField('Podaj a: ')
    b = IntegerField('Podaj b: ')
    c = IntegerField('Podaj c: ')
    submit = SubmitField('Oblicz!')

@app.route('/')
def index():
    userForm = NameForm()
    return render_template('index.html', title='Strona główna', userForm=userForm)

# @app.route('/user', methods=['POST'])
# def user():
#     userName = request.form['userName']
#     return render_template('user.html', title='Użytkownik', userName=userName)

@app.route('/user', methods=['POST'])
def user():
    userForm = NameForm()
    if userForm.validate_on_submit():
        userName = userForm.userName.data
    return render_template('user.html', title='Użytkownik', userName=userName)

@app.route('/setSession', methods=['POST', 'GET'])
def setSession():
    userForm = NameForm()
    if userForm.validate_on_submit():
        oldName = session.get('userName')
        if oldName is not None and oldName != userForm.userName.data:
            flash('Wygląda na to, że zmieniłeś imię!')
        session['userName'] = userForm.userName.data
        return redirect(url_for('setSession'))
    return render_template('session.html', title='Zastosowanie sesji', userForm=userForm, userName=session.get('userName'))

@app.route('/trinomial', methods=['POST', 'GET'])
def trinomial():
    functionForm = FunctionForm()
    if functionForm.validate_on_submit():
        a = functionForm.a.data
        b = functionForm.b.data
        c = functionForm.c.data
        delta = b**2-4*a*c
        if delta > 0:
            x1=(-b-sqrt(delta))/2*a
            x2=(-b+sqrt(delta))/2*a
            return render_template('trinomial.html', title='Funkcja kwadratowa', functionForm=functionForm, x1=round(x1, 2), x2=round(x2, 2))
        elif delta == 0:
            x1=-b/(2*a)
            return render_template('trinomial.html', title='Funkcja kwadratowa', functionForm=functionForm, x1=round(x1, 2))
        elif delta < 0:
            info = 'Brak miejsc zerowych'
            return render_template('trinomial.html', title='Funkcja kwadratowa', functionForm=functionForm, info=info)
    return render_template('trinomial.html', title='Funkcja kwadratowa', functionForm=functionForm)

@app.errorhandler(404)
def pageNotFound(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internalServerError(error):
    return render_template('500.html'), 500

if __name__ == '__main__':
    app.run(debug=True)
const express = require('express')
const app = express()
const PORT = 3000
const path = require('path')
const hbs = require('express-handlebars')
const formidable = require('formidable')
const fs = require('fs')
const fsPromises = require('fs/promises')

app.set('views', path.join(__dirname, 'views'))
app.engine('hbs', hbs({
    extname: '.hbs',
    partialsDir: 'views/partials'
    //helpers: {}
}))

app.set('view engine', 'hbs')

function getExtension(filename) {
    for (let i = filename.length - 1; i >= 0; i--) {
        if (filename[i] === '.') {
            return filename.slice(i + 1)
        }
    }
    return ''
}

function getFileIcon(filename) {
    const ext = getExtension(filename)

    switch (ext) {
        case 'doc':
        case 'docx':
            return './gfx/doc.png'
        case 'jpg':
        case 'jpeg':
            return './gfx/jpg.png'
        case 'pdf':
            return './gfx/other.png'
        case 'png':
            return './gfx/png.png'
        case 'txt':
            return './gfx/text.png'
        case 'zip':
            return './gfx/zip.png'
    }

    return './gfx/other.png'
}

async function getDirectory() {
    const dir = {
        folders: [],
        files: [],
        others: [],
    }

    const directory = fs.readdirSync(path.join(__dirname, 'pliki'))
    console.log(directory)

    await Promise.all(directory.map(async (e) => {
        const stats = await fsPromises.lstat(path.join(__dirname, 'pliki', e))
        const d = {name: e}
         
        if (stats.isDirectory()) {
            d.img = './gfx/folder.png'
            dir.folders.push(d)
        } else if (stats.isFile()) {
            d.img = getFileIcon(d.name)
            dir.files.push(d)
        } else {
            d.img = '/gfx/other.png'
            dir.others.push(d)
        }
    })
    )

    return dir
}

// function getDirectory() {
//     const dir = {
//         folders: [],
//         files: [],
//         others: [],
//     }

//     const directory = fs.readdirSync(path.join(__dirname, 'pliki'))
//     directory.forEach((e) => {
//         const stats = fs.lstatSync(path.join(__dirname, 'pliki', e))
//         if (stats.isDirectory()) {
//             dir.folders.push(e)
//         } else if (stats.isFile()) {
//             dir.files.push(e)
//         } else {
//             dir.others.push(e)
//         }
//     })

//     return dir
// }

app.get('/', async function (req, res) {
    const dir = await getDirectory()
    console.log(dir)

    res.render('index.hbs', dir)
})

app.get('/newFolder', function (req, res) {
    const name = req.query.name

    if (name) {
        const newFolder = path.join(__dirname, 'pliki', name)
        if (!fs.existsSync(newFolder)) {
            fs.mkdirSync(newFolder)
            console.log('dodane')
        } else {
            console.log('juz istnieje')
        }
        
    }
    res.redirect('/')
})

app.get('/newFile', function (req, res) {
    if (!req.query.name) {
        res.redirect('/')
        return
    }
    const type = 'txt'
    const name = getExtension(req.query.name) === type ? req.query.name : `${req.query.name}.${type}`
    
    if (name) {
        const newFile = path.join(__dirname, 'pliki', name)
        if (!fs.existsSync(newFile)) {
            fs.writeFileSync(newFile, '')
            console.log('dodane')
        } else {
            console.log('juz istnieje')
        }
        
    }
    res.redirect('/')
})

app.post('/upload', function (req, res) {
    console.log('Uploading')
    const form = formidable({})
    form.keepExtensions = true
    form.multiples = true
    form.uploadDir = path.join(__dirname, 'pliki')
    form.on('fileBegin', function (name, file) {
        file.path = form.uploadDir + '/' + file.name
    })

    form.parse(req, function (err, fields, files) {
        if (err) {
            console.log(err)
        }
        res.redirect('/')
    })
})

app.get('/delete', function (req, res) {
    if (!req.query.name) {
        res.redirect('/')
        return
    }

    const name = path.join(__dirname, 'pliki', req.query.name)
    
    if (fs.existsSync(name)) {
        const stats = fs.lstatSync(name)
        if (stats.isDirectory()) {
            fs.rmdirSync(name)
        } else {
            fs.unlinkSync(name)
        }
    } else {
        console.log('Plik do usuniecia nie istnieje:', name)
    }
    
    res.redirect('/')
})

app.use(express.static('static'))

// Nasłuchiwanie
app.listen(PORT, function () {
    console.log("Start serwera na porcie: " + PORT)
})
